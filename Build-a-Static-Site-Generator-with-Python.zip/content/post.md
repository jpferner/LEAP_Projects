---
type: post
title: Code
author: PS Demo
date: 01-28-2020
---

# Blockquotes

> Blockquotes can also be nested...
>> ...by using additional greater-than signs right next to each other...
> > > ...or with spaces between arrows.

# Syntax highlighting

```js
var foo = function (bar) {
  return bar++;
};

console.log(foo(5));
```
